/** @file spisplitshuffleplay.cpp
	stephane.poirier@oifii.org or spi@oifii.org
	@ingroup test_src
	@brief Record input into an array; Save array to a file; Playback recorded
    data. Implemented using the blocking API (Pa_ReadStream(), Pa_WriteStream() )
	@author Phil Burk  http://www.softsynth.com
    @author Ross Bencina rossb@audiomulch.com
*/
/*
 * $Id: spisplitshuffleplay.cpp 1368 2008-03-01 00:38:27Z rossb $
 *
 * This program uses the PortAudio Portable Audio Library.
 * For more information see: http://www.portaudio.com
 * Copyright (c) 1999-2000 Ross Bencina and Phil Burk
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files
 * (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge,
 * publish, distribute, sublicense, and/or sell copies of the Software,
 * and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
 * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/*
 * The text above constitutes the entire PortAudio license; however, 
 * the PortAudio community also makes the following non-binding requests:
 *
 * Any person wishing to distribute modifications to the Software is
 * requested to send the modifications to the original developer so that
 * they can be incorporated into the canonical version. It is also 
 * requested that these non-binding requests be included along with the 
 * license above.
 */

#include <stdio.h>
#include <stdlib.h>
#include "portaudio.h"

//2012mar17, spi, begin
#include "WavFile.h"
#include "SoundTouch.h"
using namespace soundtouch;
#define BUFF_SIZE	2048
//2012mar17, spi, end

#include <ctime>
#include <iostream>
#include "WavSet.h"

/* Select sample format. */
#if 1
#define PA_SAMPLE_TYPE  paFloat32
typedef float SAMPLE;
#define SAMPLE_SILENCE  (0.0f)
#define PRINTF_S_FORMAT "%.8f"
#elif 1
#define PA_SAMPLE_TYPE  paInt16
typedef short SAMPLE;
#define SAMPLE_SILENCE  (0)
#define PRINTF_S_FORMAT "%d"
#elif 0
#define PA_SAMPLE_TYPE  paInt8
typedef char SAMPLE;
#define SAMPLE_SILENCE  (0)
#define PRINTF_S_FORMAT "%d"
#else
#define PA_SAMPLE_TYPE  paUInt8
typedef unsigned char SAMPLE;
#define SAMPLE_SILENCE  (128)
#define PRINTF_S_FORMAT "%d"
#endif

/* This routine will be called by the PortAudio engine when audio is needed.
** It may called at interrupt level on some machines so don't do anything
** that could mess up the system like calling malloc() or free().
*/
static int patestCallback( const void *inputBuffer, void *outputBuffer,
                           unsigned long framesPerBuffer,
                           const PaStreamCallbackTimeInfo* timeInfo,
                           PaStreamCallbackFlags statusFlags,
                           void *userData )
{
    /* Cast data passed through stream to our structure. */
	WavSet* pWavSet = (WavSet*)userData;//paTestData *data = (paTestData*)userData;
    float *out = (float*)outputBuffer;
    unsigned int i;
    (void) inputBuffer; /* Prevent unused variable warning. */

	int idSegmentToPlay = pWavSet->idSegmentSelected+1;
	if(idSegmentToPlay>(pWavSet->numSegments-1)) idSegmentToPlay=0;
#ifdef _DEBUG
	printf("idSegmentToPlay=%d\n",idSegmentToPlay);
#endif //_DEBUG

	for( i=0; i<framesPerBuffer; i++ )
    {
        *out++ = *(pWavSet->GetPointerToSegmentData(idSegmentToPlay)+2*i);  /* left */
        *out++ = *(pWavSet->GetPointerToSegmentData(idSegmentToPlay)+2*i+1);  /* right */

        /*
		// Generate simple sawtooth phaser that ranges between -1.0 and 1.0.
        data->left_phase += 0.01f;
        // When signal reaches top, drop back down. 
        if( data->left_phase >= 1.0f ) data->left_phase -= 2.0f;
        // higher pitch so we can distinguish left and right. 
        data->right_phase += 0.03f;
        if( data->right_phase >= 1.0f ) data->right_phase -= 2.0f;
		*/
    }
	pWavSet->idSegmentSelected = idSegmentToPlay;
    return 0;
}

//////
//main
//////
int main(int argc, char *argv[]);
int main(int argc, char *argv[])
{
    PaStreamParameters outputParameters;
    PaStream* stream;
    PaError err;
	WavSet* pWavSet = NULL;

	///////////////////
	//read in arguments
	///////////////////
	//char charBuffer[2048] = {"testbeat.wav"}; //usage: spisplitshuffleplay testbeat2.wav 0.5 10
	char charBuffer[2048] = {"CLK_DN_01.WAV"}; //usage: spisplitshuffleplay testbeat2.wav 0.5 10
	//double fSecondsPerSegment = 1.0; //non-zero for spliting sample into sub-segments
	double fSecondsPerSegment = 1.0; //non-zero for spliting sample into sub-segments
	//float fSecondsPlay = 30; //positive for number of seconds to play/loop
	float fSecondsPlay = -1.0; //negative for playing only once
	if(argc>1)
	{
		//first argument is the filename
		sprintf_s(charBuffer,2048-1,argv[1]);
	}
	if(argc>2)
	{
		//second argument is the segment length in seconds
		fSecondsPerSegment = atof(argv[2]);
	}
	if(argc>3)
	{
		//third argument is the time it will shuffle
		fSecondsPlay = atof(argv[3]);
	}


	//////////////////////////////////
	//read a WAV file using soundtouch 
	//////////////////////////////////
	pWavSet = new WavSet;
	pWavSet->ReadWavFile(charBuffer);

	
	////////////////////////////////////
	// play loaded data using port audio 
	////////////////////////////////////
    err = Pa_Initialize();
    if( err != paNoError ) goto error;

	outputParameters.device = Pa_GetDefaultOutputDevice(); // default output device 
	if (outputParameters.device == paNoDevice) 
	{
		fprintf(stderr,"Error: No default output device.\n");
		goto error;
	}
	outputParameters.channelCount = pWavSet->numChannels;
	outputParameters.sampleFormat =  PA_SAMPLE_TYPE;
	outputParameters.suggestedLatency = Pa_GetDeviceInfo( outputParameters.device )->defaultLowOutputLatency;
	outputParameters.hostApiSpecificStreamInfo = NULL;

#ifdef _DEBUG //debug: playback the loaded sample file (as is)
	if(0)
	{
		printf("Begin playback.\n"); fflush(stdout);
		err = Pa_OpenStream(
					&stream,
					NULL, // no input
					&outputParameters,
					pWavSet->SampleRate,
					BUFF_SIZE/pWavSet->numChannels, //FRAMES_PER_BUFFER,
					paClipOff,      // we won't output out of range samples so don't bother clipping them 
					NULL, // no callback, use blocking API 
					NULL ); // no callback, so no callback userData 
		if( err != paNoError ) goto error;

		if( stream )
		{
			err = Pa_StartStream( stream );
			if( err != paNoError ) goto error;
			printf("Waiting for playback to finish.\n"); fflush(stdout);

			err = Pa_WriteStream( stream, pWavSet->pSamples, pWavSet->totalFrames );
			if( err != paNoError ) goto error;

			err = Pa_CloseStream( stream );
			if( err != paNoError ) goto error;
			printf("Done.\n"); fflush(stdout);
		}
	}
#endif //_DEBUG

	

	///////////////////////////
	// split WavSet in segments 
	///////////////////////////
	pWavSet->SplitInSegments(fSecondsPerSegment);
#ifdef _DEBUG
	printf("numSegments=%d\n",pWavSet->numSegments);
#endif //_DEBUG

	//////////////////////////
	//initialize random number
	//////////////////////////
	srand((unsigned)time(0));
	
	///////////////////////////////////////////////////////////////////
	//play WavSet's segments sequentially using portaudio with callback
	///////////////////////////////////////////////////////////////////
	err = Pa_OpenStream(
				&stream,
				NULL, // no input
				&outputParameters,
				pWavSet->SampleRate,
				pWavSet->numSamplesPerSegment/pWavSet->numChannels, //BUFF_SIZE/pWavSet->numChannels, //FRAMES_PER_BUFFER,
				paClipOff,      // we won't output out of range samples so don't bother clipping them 
				patestCallback, // no callback, use blocking API 
				pWavSet ); // no callback, so no callback userData 
	if( err != paNoError ) goto error;

    err = Pa_StartStream( stream );
    if( err != paNoError ) goto error;

	if(fSecondsPlay>0.0)
	{
		//Sleep for fSecondsPlay seconds. 
		Pa_Sleep(fSecondsPlay*1000);
	}
	else
	{
		//Sleep for wavfile's length
		float fSegmentsLength = pWavSet->GetSegmentsLength();
		printf("sleep for %f sec\n", fSegmentsLength);
		Pa_Sleep(fSegmentsLength*1000);
	}

    err = Pa_StopStream( stream );
    if( err != paNoError ) goto error;

	if( stream )
	{
		err = Pa_CloseStream( stream );
		if( err != paNoError ) goto error;
		printf("Done.\n"); fflush(stdout);
	}
	Pa_Terminate();
	if(pWavSet) delete pWavSet;
	printf("Exiting!\n"); fflush(stdout);
	return 0;
	


error:
    Pa_Terminate();
    fprintf( stderr, "An error occured while using the portaudio stream\n" );
    fprintf( stderr, "Error number: %d\n", err );
    fprintf( stderr, "Error message: %s\n", Pa_GetErrorText( err ) );
    return -1;

}

